<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\Pengaturan;

/**
 * Halaman Pengaturan: identitas usaha, logo, & pesan struk (ala Majoo).
 */
class PengaturanController extends Controller
{
    private const LOGO_DIR  = '/asset/logo';
    private const LOGO_MAX  = 1048576; // 1 MB
    private const LOGO_MIME = [
        'image/png'  => 'png',
        'image/jpeg' => 'jpg',
        'image/webp' => 'webp',
        'image/gif'  => 'gif',
    ];

    /** Tab halaman pengaturan (panel yang aktif ditampilkan di form). */
    private const TAB = ['umum', 'struk', 'keuangan', 'keamanan', 'notifikasi'];

    public function index(): void
    {
        $this->requireHak('pengaturan');

        $model = new Pengaturan();
        $data  = $model->semua();

        // Jamin kunci default selalu tampil di form
        foreach (array_keys($model->identitasDefault()) as $k) {
            if (!isset($data[$k])) {
                $data[$k] = '';
            }
        }
        $data['logo'] = $data['logo'] ?? '';

        $tab = (string)($_GET['tab'] ?? 'umum');
        if (!in_array($tab, self::TAB, true)) {
            $tab = 'umum';
        }

        $this->view('pengaturan/index', [
            'pageTitle' => 'Pengaturan',
            'active'    => 'pengaturan',
            's'         => $data,
            'tab'       => $tab,
            'logoUrl'   => $data['logo'] ? self::logoUrl($data['logo']) : '',
        ]);
    }

    /** Simpan pengaturan + logo (bila diunggah). */
    public function simpan(): void
    {
        $this->requireHak('pengaturan');

        $model   = new Pengaturan();
        $payload = [];

        // Kunci teks dari form + validasi angka
        foreach (array_keys($model->identitasDefault()) as $k) {
            $payload[$k] = (string)($_POST[$k] ?? '');
        }
        foreach ($model->validasiAngka() as $k => [$min, $max]) {
            $nilai = (int)$payload[$k];
            if ($nilai < $min) {
                $nilai = $min;
            }
            if ($nilai > $max) {
                $nilai = $max;
            }
            $payload[$k] = (string)$nilai;
        }

        // Prefix nota: huruf besar, hanya huruf/angka, maks 8 karakter
        $prefix = strtoupper(trim($payload['prefix_nota']));
        $prefix = preg_replace('/[^A-Z0-9]/', '', $prefix);
        $payload['prefix_nota'] = ($prefix === '' ? 'LND' : mb_substr($prefix, 0, 8));

        // Satuan & mata uang dibatasi panjangnya
        $payload['satuan_berat'] = mb_substr(trim((string)$payload['satuan_berat']), 0, 10) ?: 'kg';
        $payload['mata_uang']    = mb_substr(trim((string)$payload['mata_uang']), 0, 6) ?: 'Rp';

        // Suara notifikasi: checkbox -> '1'/'0'
        $payload['notif_suara'] = empty($_POST['notif_suara']) ? '0' : '1';

        // Hapus logo bila diminta
        if (!empty($_POST['hapus_logo'])) {
            $this->hapusBerkasLogo($model->nilai('logo'));
            $payload['logo'] = '';
        }

        // Upload logo baru
        $file = $_FILES['logo'] ?? null;
        if ($file && is_array($file) && ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK && $file['size'] > 0) {
            $nama = $this->simpanBerkasLogo($file);
            if ($nama === null) {
                // Berkas tidak valid: tetap simpan teks lain, beri peringatan
                $model->simpan($payload);
                setFlash('error', 'Pengaturan lain disimpan, tetapi logo tidak diunggah: gunakan PNG/JPG/WebP/GIF maksimal 1 MB.');
                $this->redirect('pengaturan');
            }
            $this->hapusBerkasLogo($model->nilai('logo'));
            $payload['logo'] = $nama;
        }

        $model->simpan($payload);

        setFlash('success', 'Pengaturan berhasil disimpan.');
        logAktivitas('pengaturan_simpan', 'Menyimpan pengaturan usaha' .
            (!empty($_POST['hapus_logo']) ? ' + hapus logo' : ''));

        // Kembali ke tab yang sama setelah disimpan
        $tab = (string)($_POST['tab'] ?? 'umum');
        if (!in_array($tab, self::TAB, true)) {
            $tab = 'umum';
        }
        $this->redirect('pengaturan', $tab === 'umum' ? [] : ['tab' => $tab]);
    }

    /** Hapus logo dari penyimpanan & database. */
    public function hapusLogo(): void
    {
        $this->requireHak('pengaturan');

        $model = new Pengaturan();
        $this->hapusBerkasLogo($model->nilai('logo'));
        $model->simpan(['logo' => '']);

        setFlash('success', 'Logo toko berhasil dihapus.');
        logAktivitas('pengaturan_logo', 'Menghapus logo toko');
        $this->redirect('pengaturan');
    }

    /** Simpan berkas logo ke folder asset/logo, kembalikan nama berkas. */
    private function simpanBerkasLogo(array $file): ?string
    {
        $mime = trim((string)($file['type'] ?? ''));
        if (!isset(self::LOGO_MIME[$mime])) {
            // Jangan percaya type dari browser; cek isi berkas
            $info = @getimagesize($file['tmp_name']);
            if (!$info || !isset(self::LOGO_MIME[$info['mime']])) {
                return null;
            }
            $mime = $info['mime'];
        }
        if ($file['size'] > self::LOGO_MAX) {
            return null;
        }

        $dir = BASE_PATH . self::LOGO_DIR;
        if (!is_dir($dir) && !@mkdir($dir, 0775, true)) {
            return null;
        }

        $ext  = self::LOGO_MIME[$mime];
        $nama = 'logo-' . date('Ymd-His') . '-' . bin2hex(random_bytes(4)) . '.' . $ext;

        if (!@move_uploaded_file($file['tmp_name'], $dir . '/' . $nama)) {
            return null;
        }
        return $nama;
    }

    /** Hapus berkas logo lama dari disk bila ada. */
    private function hapusBerkasLogo(string $nama): void
    {
        if ($nama === '') {
            return;
        }
        $berkas = BASE_PATH . self::LOGO_DIR . '/' . basename($nama);
        if (is_file($berkas)) {
            @unlink($berkas);
        }
    }

    /** URL lengkap ke berkas logo. */
    public static function logoUrl(string $nama): string
    {
        return base_path() . self::LOGO_DIR . '/' . rawurlencode($nama);
    }
}