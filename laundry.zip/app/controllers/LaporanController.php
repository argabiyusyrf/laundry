<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\Transaksi;

/**
 * Laporan + export CSV.
 */
class LaporanController extends Controller
{
    /** Ambil rentang tanggal dari input, dengan default bulan berjalan. */
    private function rentang(): array
    {
        $from = $_GET['from'] ?? date('Y-m-01');
        $to   = $_GET['to'] ?? date('Y-m-d');

        $tFrom = strtotime((string)$from);
        $tTo   = strtotime((string)$to);

        return [
            'from' => $tFrom ? date('Y-m-d', $tFrom) : date('Y-m-01'),
            'to'   => $tTo ? date('Y-m-d', $tTo) : date('Y-m-d'),
        ];
    }

    public function index(): void
    {
        $this->requireHak('laporan');

        ['from' => $from, 'to' => $to] = $this->rentang();
        $data = (new Transaksi())->laporan($from, $to);

        $this->view('laporan/index', [
            'pageTitle' => 'Laporan',
            'active'    => 'laporan',
            'from'      => $from,
            'to'        => $to,
            'list'      => $data['list'],
            'totNilai'  => $data['totNilai'],
            'totBerat'  => $data['totBerat'],
            'totDibayar'=> $data['totDibayar'],
            'belumSelesai' => $data['belumSelesai'],
        ]);
    }

    public function export(): void
    {
        $this->requireHak('laporan');

        ['from' => $from, 'to' => $to] = $this->rentang();
        $list = (new Transaksi())->laporan($from, $to)['list'];

        logAktivitas('laporan_export', 'Export CSV laporan ' . $from . ' s/d ' . $to);

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="laporan-laundry-' . $from . '_' . $to . '.csv"');

        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF"); // BOM agar terbaca di Excel
        fputcsv($out, ['No Nota', 'Tanggal Masuk', 'Pelanggan', 'Berat (kg)', 'Total Harga', 'Dibayar', 'Status', 'Pembayaran']);

        foreach ($list as $t) {
            $dibayar = $t['status_bayar'] === 'lunas' ? $t['total_harga'] : $t['uang_muka'];
            fputcsv($out, [
                $t['no_nota'],
                $t['tanggal_masuk'],
                $t['pelanggan'],
                $t['total_berat'],
                $t['total_harga'],
                $dibayar,
                STATUS_LABEL[$t['status']] ?? $t['status'],
                $t['status_bayar'] === 'lunas' ? 'Lunas' : 'Belum Lunas',
            ]);
        }

        fclose($out);
        exit;
    }
}