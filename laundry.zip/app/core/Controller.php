<?php
namespace App\Core;

/**
 * Controller dasar: memuat view, redirect, dan proteksi login.
 */
abstract class Controller
{
    /** Render view dengan data. View dipanggil dalam satu scope agar variabel tersedia. */
    protected function view(string $view, array $data = []): void
    {
        extract($data, EXTR_SKIP);

        $file = VIEW_PATH . '/' . $view . '.php';
        if (!is_file($file)) {
            throw new \RuntimeException('View tidak ditemukan: ' . $view);
        }

        require $file;
    }

    /** Redirect ke route lain: ?r=route&params */
    protected function redirect(string $route, array $params = []): void
    {
        header('Location: ' . url($route, $params));
        exit;
    }

    /**
     * Redirect kembali ke halaman asal bila form membawa field "kembali"
     * (URL internal aplikasi), sehingga filter pencarian tetap dipertahankan.
     */
    protected function redirectKembali(string $fallbackRoute, array $params = []): void
    {
        $tujuan = trim((string)($_POST['kembali'] ?? ($_GET['kembali'] ?? '')));
        $base   = rtrim(BASE_REL, '/') . '/';

        // Terima hanya URL internal (mis. /laundry/index.php?r=...) untuk mencegah open redirect
        if ($tujuan !== '' && strpos($tujuan, $base) === 0 && strpos($tujuan, '://') === false) {
            header('Location: ' . $tujuan);
            exit;
        }

        $this->redirect($fallbackRoute, $params);
    }

    /** Wajib login, jika belum login arahkan ke halaman login. */
    protected function requireLogin(): void
    {
        if (empty($_SESSION['user'])) {
            /* Simpan halaman yang dituju agar setelah login kembali ke sana (bukan dashboard).
               Hanya untuk GET; form POST tidak bisa diulang dengan GET setelah login. */
            $uri = $_SERVER['REQUEST_URI'] ?? '';
            if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET'
                && is_string($uri) && $uri !== '' && strpos($uri, '://') === false) {
                $base = rtrim(BASE_REL, '/');
                if ($base === '' || $uri === $base || strpos($uri, $base . '/') === 0) {
                    $_SESSION['login_back'] = $uri;
                }
            }
            $this->redirect('login');
        }

        /* Sesi kedaluwarsa: bila diaktifkan di Pengaturan -> Keamanan Akun.
           User yang terlalu lama tidak beraktivitas otomatis logout. */
        $menit = (int)pengaturan('sesi_kedaluwarsa_menit', '0');
        if ($menit > 0) {
            $terakhir = (int)($_SESSION['last_activity'] ?? 0);
            if ($terakhir > 0 && time() - $terakhir > $menit * 60) {
                logAktivitas('logout', 'Sesi berakhir otomatis (tidak aktif ' . $menit . ' menit)');
                $_SESSION = [];
                session_destroy();
                session_start();
                session_regenerate_id(true);
                setFlash('info', 'Sesi Anda berakhir karena terlalu lama tidak aktif. Silakan login kembali.');
                $this->redirect('login');
            }
        }
        $_SESSION['last_activity'] = time();
    }

    /** Data user yang sedang login. */
    protected function currentUser(): array
    {
        return $_SESSION['user'] ?? [];
    }

    /**
     * Wajib login + memiliki izin menu (lihat HAK_AKSES di config.php).
     * Bila role tidak berhak, tampilkan halaman 403 (larangan akses).
     */
    protected function requireHak(string $menu): void
    {
        $this->requireLogin();
        if (!cekHak($menu)) {
            tampilkanError(403, 'Anda tidak memiliki izin untuk mengakses halaman ini.');
        }
    }
}