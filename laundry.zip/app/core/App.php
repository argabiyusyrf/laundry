<?php
namespace App\Core;

/**
 * Router + Dispatcher sederhana.
 * Route dibaca dari parameter "r":   ?r=controller/method/param1/param2
 *
 * Contoh:
 *   ?r=dashboard                 -> DashboardController::index()
 *   ?r=panggilan                 -> (default method: index)
 *   ?r=transaksi/detail/4        -> TransaksiController::detail(4)
 *   ?r=laporan/export            -> LaporanController::export()
 */
class App
{
    public function run(): void
    {
        $r = trim((string)($_GET['r'] ?? ''));

        /* Fallback PATH_INFO untuk server tanpa mod_rewrite, mis. /index.php/dashboard */
        if ($r === '' && !empty($_SERVER['PATH_INFO'])) {
            $r = ltrim(trim($_SERVER['PATH_INFO']), '/');
        }

        if ($r === '') {
            $r = 'auth';
        }

        $segments   = explode('/', $r);

        /* Alias: route login/logout → AuthController::login / AuthController::logout */
        if ($segments[0] === 'login' || $segments[0] === 'logout') {
            $class  = 'App\\Controllers\\AuthController';
            $method = $segments[0];
            $params = array_slice($segments, 1);
        } else {
            $controller = ucfirst($segments[0]);
            $method     = $segments[1] ?? 'index';
            $params     = array_slice($segments, 2);
            $class      = 'App\\Controllers\\' . $controller . 'Controller';

            /* Normalisasi kebab-case ke camelCase: hapus-logo -> hapusLogo */
            if (strpos($method, '-') !== false) {
                $method = lcfirst(str_replace(' ', '', ucwords(str_replace('-', ' ', $method))));
            }
        }

        if (!class_exists($class)) {
            $this->abort(404, 'Halaman tidak ditemukan.');
            return;
        }

        $instance = new $class();

        if (!is_callable([$instance, $method])) {
            $this->abort(404, 'Halaman tidak ditemukan.');
            return;
        }

        call_user_func_array([$instance, $method], $params);
    }

    private function abort(int $kode, string $pesan): void
    {
        tampilkanError($kode, $pesan);
    }
}