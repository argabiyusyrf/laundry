# RENCANA MULTI-USER — LaundryKu

Dokumen perencanaan & implementasi fitur **multi-user** aplikasi LaundryKu
(kasir/manajemen laundry, PHP murni + MySQL, MVC custom).

- **Bab 1–9**: rencana awal multi-user yang terwujud di **v2.0** (3 role + hak akses matriks).
- **Bab 10**: **Addendum v2.1** — permintaan akun toko, kelola karyawan, pengaturan 6 kelompok,
  beserta dampaknya pada skema database, matriks hak, dan langkah deploy.

Status dokumen: **TERAPKAN** (v2.0 + v2.1).

---

## Daftar Isi

1. Latar Belakang & Tujuan
2. Peran Pengguna (3 Role)
3. Matriks Hak Akses (v2.0)
4. Skema Database & Migrasi
5. Alur Kerja (Workflow)
6. Keamanan Multi-User
7. Strategi Pengujian
8. Deploy & Instalasi
9. Rencana Lanjutan (Roadmap)
10. **Addendum v2.1** (10.1–10.5)

---

## Bab 1. Latar Belakang & Tujuan

LaundryKu awalnya aplikasi admin tunggal (satu akun, satu toko). Kebutuhan nyata di lapangan:

- Pemilik sistem (developer/penjual) menyerahkan aplikasi ke **klien** yang mengelola toko.
- Klien punya **karyawan counter** yang hanya perlu melayani transaksi harian.
- Tidak semua pengguna boleh melihat keuangan, mengubah pengaturan, atau menghapus nota.

Tujuan v2.0: memperkenalkan **3 peran** dengan **hak akses per menu + aksi kunci**,
dikontrol oleh satu matriks `HAK_AKSES` di `app/config/config.php`. Sistem tetap
**satu outlet** (belum multi-cabang).

## Bab 2. Peran Pengguna (3 Role)

| Role | Label | Siapa | Inti Tugas |
|---|---|---|---|
| `root` | Pemilik Sistem | Penjual/pengembang yang mengatur siapa yang boleh memakai | Kelola semua akun + akses penuh semua menu |
| `manager` | Manager Toko | Pengelola toko (klien) | Operasional, keuangan, koreksi nota, laporan, pengaturan toko, lihat log aktivitas |
| `staff` | Staff / Kasir | Karyawan di counter | Melayani transaksi harian: nota, status cucian, pembayaran, daftar pelanggan baru |

```
root (Pemilik Sistem) —— membuat & mengontrol SEMUA akun
  │  akses penuh + kelola akun
  ▼
manager (Manager Toko) —— operasional + keuangan + koreksi + laporan
  │  membuat nota/hapus berdasarkan hak; mengawasi staff
  ▼
staff (Kasir) —— melayani counter: nota, status, pembayaran, pelanggan baru
```

## Bab 3. Matriks Hak Akses (v2.0)

| Menu / Aksi | root | manager | staff |
|---|:---:|:---:|:---:|
| Dashboard (ringkasan) | ✓ | ✓ | ✓ (versi ringkas, tanpa nilai keuangan) |
| Pelanggan: daftar/cari/detail/tambah | ✓ | ✓ | ✓ |
| Pelanggan: ubah / hapus | ✓ | ✓ | ✗ |
| Paket: lihat daftar | ✓ | ✓ | ✓ (untuk buat nota) |
| Paket: tambah / ubah / hapus | ✓ | ✓ | ✗ |
| Transaksi: lihat / buat nota / status / bayar / cetak | ✓ | ✓ | ✓ |
| Transaksi: ubah / hapus nota | ✓ | ✓ | ✗ (koreksi oleh manager) |
| Laporan + export CSV | ✓ | ✓ | ✗ |
| Pengaturan usaha | ✓ | ✓ | ✗ |
| Akun & Pengguna (root-only) | ✓ | ✗ | ✗ |
| Log Aktivitas | ✓ | ✓ | ✗ |
| Notifikasi (lonceng, baca) | ✓ | ✓ | ✓ |
| Profil (nama tampilan, ganti password sendiri) | ✓ | ✓ | ✓ |

## Bab 4. Skema Database & Migrasi

- `users` + kolom `role`, `aktif`, `last_login`, `gagal_login`, `terkunci_hingga`.
- Tabel baru `log_aktivitas` (waktu, pelaku, aksi, detail, IP).
- `install.php` melakukan **migrasi idempotent**: menambah kolom/relasi pada database
  lama secara otomatis (admin lama menjadi `root`, akun tetap aktif).
- Semua query memakai **prepared statement** (PDO) dengan `ERRMODE_EXCEPTION`.

## Bab 5. Alur Kerja (Workflow)

- **W1 — Membuat akun (root):** menu Akun & Pengguna → tambah akun → akun langsung aktif.
- **W2 — Login:** cek status aktif + password bcrypt; role masuk session; sidebar
  menampilkan menu yang diizinkan; login/logout tercatat di log aktivitas.
- **W3 — Transaksi harian (staff):** daftar/cari pelanggan → buat nota → cetak →
  update status → terima pembayaran.
- **W4 — Koreksi nota (manager):** ubah (sebelum lunas) atau hapus (nota dobel) → tercatat.
- **W5 — Keuangan (manager):** Laporan per rentang tanggal → ringkasan + export CSV →
  cek Log Aktivitas bila ada selisih.

## Bab 6. Keamanan Multi-User

- Menu disembunyikan **dan** route divalidasi server-side (`requireHak`) — URL manual
  tidak bisa membobol; pelanggaran menampilkan 403.
- Staff tidak bisa mengubah role/status akun sendiri; root tidak bisa menghapus akun
  diri sendiri atau mematikan root terakhir (sistem menjaga jangan sampai terkunci keluar).
- Akun nonaktif langsung ditolak saat login; login bruto-force dibatasi (kunci sementara).
- Semua aksi penting tercatat di `log_aktivitas` (waktu, pelaku, IP).

## Bab 7. Strategi Pengujian

- Pengujian E2E otomatis (`_uji_v21.php`) terhadap alur: login tiap role, cetak zona
  hak (3 role x menu), menu dinamis, 403, permintaan akun, karyawan, pengaturan,
  migrasi idempotent — keseluruhan **56/56 lolos** pada skema v2.1.
- Verifikasi manual: render halaman publik, flash, badge status, struktur zip deploy,
  serta keberadaan file & tabel di server hosting.

## Bab 8. Deploy & Instalasi

1. Upload seluruh isi folder `laundry` (zip) ke `htdocs` hosting.
2. Buka `install.php` sekali (migrasi + seed otomatis; hosting = database bersih,
   lokal = ikut data contoh).
3. Hapus `install.php` dan `inspeksi.php` dari server.
4. Login `admin` / `admin123` (root) → ganti password.
5. `doc.docx` dan `RENCANA-MULTIUSER.md` adalah dokumen deliverable — **tidak di-upload**,
   hanya disimpan dalam `laundry.zip`.

## Bab 9. Rencana Lanjutan (Roadmap)

- Laporan per kasir, grafik pendapatan.
- Aplikasi customer untuk cek status cucian.
- Multi-cabang (setiap cabang punya manager sendiri).
- Notifikasi realtime lintas perangkat.

---

# Bab 10. Addendum v2.1

Perubahan besar v2.1: **alur permintaan akun toko (bukan self-register)**,
**kelola karyawan oleh manager**, dan **pengaturan usaha diperluas jadi 6 kelompok**
— semuanya ter-wire ke sistem (pajak, diskon, DP, prefix nota, satuan/mata uang,
keamanan akun).

## 10.1 Minta Akun Toko (bukan self-register)

Calon pengelola toko **tidak bisa mendaftar akun sendiri**. Alur:

```
Halaman login → tautan "Minta Akun Toko" → isi formulir publik
   (nama toko, nama pemohon, username & password pilihan, kontak)
        │
        ▼
Permintaan masuk ke root (notifikasi lonceng + tab "Permintaan" di menu Akun)
        │
        ├─ DISETUJUI → akun MANAGER dibuat otomatis dengan kredensial pemohon
        │              → pemohon langsung bisa login
        └─ DITOLAK   → beri alasan → pemohon bisa cek status & mengulang
```

- Kredensial berasal dari **pemohon** (username/password pilihan) — bukan dibuat root.
- Akun hanya menjadi aktif (manager) **setelah disetujui root**.
- Halaman publik **Cek Status Permintaan** (`?r=permintaan/status`) menampilkan form
  "Sudah mengajukan? Cek status" terpisah dari form Minta Akun: pemohon memasukkan
  username → kartu hasil berisi nama toko, pemohon, tanggal pengajuan, dan badge
  status (Menunggu Persetujuan / Disetujui / Ditolak + catatan).
- Username yang sama tidak boleh diminta dua kali (status menunggu) atau dipakai akun lain.
- Data tersimpan di tabel baru `permintaan_akun`:
  `jenis, nama_toko, nama_pemohon, username, password_hash, telepon, alamat, catatan,
  status('menunggu','disetujui','ditolak'), diproses_oleh → users, diproses_at, created_at`.

## 10.2 Kelola Karyawan (manager langsung buat staff)

- Menu **Karyawan** tersedia untuk **root & manager**.
- Manager membuat akun **staff langsung** (nama, username, password) tanpa lewat root,
  mengubah data, reset password, dan menghapus akun.
- Ini "persetujuan toko" untuk karyawan: manajer yang menyetujui; **root tidak ikut
  persetujuan toko** (root hanya mengelola level manager ke atas & seluruh sistem).
- Akun karyawan/staff **tidak** lewat tabel `permintaan_akun`.

## 10.3 Pengaturan diperluas — 6 kelompok

| Kelompok | Isi |
|---|---|
| **Identitas & Kontak** | nama usaha, alamat, telepon/WA, Instagram, email, jam buka–tutup |
| **Struk & Nota** | header struk, promo struk, catatan struk, footer struk |
| **Pajak & Diskon** | pajak layanan (%), batas maks. diskon (%), DP minimal (%) |
| **Format Nomor Nota** | prefix nota (otomatis dihurufbesarkan, maks 8 karakter) |
| **Satuan & Mata Uang** | satuan berat (kg, kodi, pcs, dst.) & simbol mata uang (Rp, IDR, dst.) |
| **Keamanan Akun** | min. panjang password, jeda sesi kedaluwarsa (menit, 0 = tanpa batas), batas percobaan login gagal |

Yang langsung terpakai di sistem:

- **Pajak** dihitung otomatis: `subtotal × pajak%` ditambahkan ke total nota
  (tampil di ringkasan, detail, dan struk).
- **Diskon** per nota: nilai dibatasi `diskon_maks_persen`% dari subtotal;
  default 0% = tanpa batas.
- **DP minimal**: bila diisi > 0, nota wajib uang muka minimal `dp_minimal_persen`%
  dari total (ditolak bila kurang).
- **Prefix nota** dipakai generator `no_nota` (`PREFIX-YYYYMMDD-XXX`).
- **Satuan & mata uang** dipakai di seluruh tampilan — tidak ada teks `kg`/`Rp` yang
  diketik manual.
- **Keamanan akun**: login terkunci sementara setelah melewati `batas_login_gagal`;
  password wajib ≥ `min_password` karakter; sesi otomatis logout bila
  `sesi_kedaluwarsa_menit` > 0.

> Default `pajak_persen = 0`, `diskon = 0`, `dp_minimal_persen = 0` sehingga perilaku
> nota lama tidak berubah; baris pajak/diskon hanya tampil bila nilainya > 0.

## 10.4 Perubahan skema database v2.1

- `users` + `gagal_login`, `terkunci_hingga`.
- `transaksi` + `diskon`, `pajak` (DECIMAL(12,2), default 0).
- Tabel baru `permintaan_akun` (lihat 10.1).
- `pengaturan` + 16 kunci baru (total **22 kunci**) — `install.php` melakukan migrasi
  idempotent pada database lama secara otomatis (seed 22 kunci dengan nilai netral).
- Migrasi aman dijalankan berulang (CREATE TABLE IF NOT EXISTS / cek kolom).

## 10.5 Matriks hak akses v2.1 + dampak deploy

| Menu / Aksi | root | manager | staff |
|---|:---:|:---:|:---:|
| Dashboard (ringkasan) | ✓ | ✓ | ✓ (versi ringkas, tanpa nilai keuangan) |
| Pelanggan: daftar/cari/detail/tambah | ✓ | ✓ | ✓ |
| Pelanggan: ubah / hapus | ✓ | ✓ | ✗ |
| Paket: lihat daftar | ✓ | ✓ | ✓ (untuk buat nota) |
| Paket: tambah / ubah / hapus | ✓ | ✓ | ✗ |
| Transaksi: lihat / buat nota / status / bayar / cetak | ✓ | ✓ | ✓ |
| Transaksi: ubah / hapus nota | ✓ | ✓ | ✗ (koreksi oleh manager) |
| Laporan + export CSV | ✓ | ✓ | ✗ |
| Pengaturan usaha (6 kelompok) | ✓ | ✓ | ✗ |
| **Karyawan** (tambah staff / ubah / reset / hapus) | ✓ | ✓ | ✗ |
| **Permintaan Akun Toko** (setujui / tolak) | ✓ | ✗ | ✗ |
| **Akun & Pengguna** (tambah/ubah role/aktif/reset/hapus) | ✓ | ✗ | ✗ |
| **Log Aktivitas** | ✓ | ✓ | ✗ |
| Notifikasi (lonceng, baca) | ✓ | ✓ | ✓ |
| Profil (nama tampilan, ganti password sendiri) | ✓ | ✓ | ✓ |

Dampak deploy:

1. Upload seluruh isi folder `laundry` (zip berisi `doc.docx` + `RENCANA-MULTIUSER.md`
   sebagai deliverable; `.docx` **tidak di-upload** ke server).
2. Buka `install.php` sekali → migrasi + seed 22 kunci pengaturan.
3. Hapus `install.php` + `inspeksi.php` dari server.
4. Verifikasi: login root → tab "Permintaan" di menu Akun muncul; submit formulir
   publik diuji; `?r=permintaan/status` menampilkan kartu status.
5. Catatan keamanan: ganti password root segera, kredensial DB hanya di `config.php`.

---

*Dokumen ini bagian dari deliverable LaundryKu v2.1. Terakhir diperbarui bersama rilis v2.1.*