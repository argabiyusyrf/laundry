<?php
declare(strict_types=1);

/**
 * ============================================================
 *  LaundryKu — Front Controller (bootstrap + router)
 *  Semua request masuk ke file ini:
 *      http://localhost/laundry/index.php?r=dashboard
 *      http://localhost/laundry/index.php?r=transaksi/detail/4
 * ============================================================
 */

error_reporting(E_ALL);

/* --- Jalur & URL dasar --- */
define('APP_PATH', __DIR__ . '/app');
define('VIEW_PATH', APP_PATH . '/views');
define('BASE_PATH', __DIR__);
define('BASE_REL', rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/'));
define('LOG_PATH', __DIR__ . '/storage/logs');

session_start();

/* --- Log error ke file ---------------------------------------------------------
 * Semua kesalahan (exception, fatal error PHP, warning) dicatat ke folder
 * storage/logs/. File log tidak bisa dibuka lewat browser (dilindungi .htaccess),
 * hanya terbaca lewat File Manager hosting atau halaman inspeksi.php.
 * ----------------------------------------------------------------------------- */
if (!is_dir(LOG_PATH)) {
    @mkdir(LOG_PATH, 0775, true);
}
ini_set('log_errors', '1');
ini_set('error_log', LOG_PATH . '/php-errors.log');

/* Tangkap error fatal yang terjadi SEBELUM blok try (mis. saat require config).
   Bila file config.php bermasalah, error tetap tercatat ke file log. */
register_shutdown_function(function () {
    $err = error_get_last();
    if ($err === null) {
        return;
    }
    $fatal = [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR];
    if (!in_array($err['type'], $fatal, true)) {
        return;
    }
    if (defined('LOG_PATH')) {
        $baris = sprintf(
            "[%s] FATAL %s di %s:%d%s",
            date('Y-m-d H:i:s'),
            $err['message'],
            $err['file'],
            $err['line'],
            PHP_EOL
        );
        @file_put_contents(LOG_PATH . '/laundryku-' . date('Y-m-d') . '.log', $baris, FILE_APPEND | LOCK_EX);
    }
});

require APP_PATH . '/config/config.php';
require APP_PATH . '/core/Autoload.php';
require APP_PATH . '/helpers/helpers.php';

/* Tampil detail error di localhost (APP_DEBUG=true), disembunyikan di produksi.
   Yang disembunyikan hanya TAMPILAN di layar — pencatatan ke file log tetap jalan. */
ini_set('display_errors', APP_DEBUG ? '1' : '0');

use App\Core\App;

try {
    (new App())->run();
} catch (Throwable $e) {
    /* Catat ke file log (detail penuh) sebelum merender halaman error.
       Dibungkus try/catch agar kegagalan menulis log tidak menimbulkan fatal baru. */
    try {
        \App\Core\Log::tulis('ERROR', $e->getMessage() . ' — ' . $e->getFile() . ':' . $e->getLine());
    } catch (\Throwable $logE) {
        /* Abaikan: halaman error tetap ditampilkan. */
    }

    /* Error boundary: halaman 500 yang utuh (berikut detail di mode pengembangan). */
    $detail = '';
    if (defined('APP_DEBUG') && APP_DEBUG) {
        $detail = $e->getMessage() . ' — ' . $e->getFile() . ':' . $e->getLine();
    }
    tampilkanError(500, 'Sistem mengalami gangguan tak terduga saat memproses permintaan.', $detail);
}